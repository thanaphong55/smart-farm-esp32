SMART FARM WEB
ไฟล์ในชุดนี้:
- index.html : หน้า Dashboard เปิดด้วยเว็บเบราว์เซอร์ได้ทันที
- esp32_smartfarm.ino : โค้ดตัวอย่าง ESP32 สำหรับส่งข้อมูลและรับคำสั่งจากหน้าเว็บ

ทดลองหน้าเว็บ:
1. เปิด index.html ด้วย Chrome/Edge
2. ค่าเริ่มต้นเป็นโหมดตัวอย่าง (demoMode = true) จึงแสดงค่าจำลองและไม่ควบคุมอุปกรณ์จริง

เชื่อมต่อ ESP32:
1. อัปโหลด esp32_smartfarm.ino ผ่าน Arduino IDE
2. ติดตั้งไลบรารี DHT sensor library by Adafruit และ ArduinoJson
3. ใส่ชื่อ/รหัส Wi-Fi และตรวจสอบหมายเลขขาให้ตรงวงจร
4. เปิด Serial Monitor ที่ 115200 เพื่อดู IP ของ ESP32
5. ใน index.html เปลี่ยน ESP32_URL เป็น IP ที่ได้ และตั้ง demoMode = false
6. เปิดหน้าเว็บจากอุปกรณ์ใน Wi-Fi วงเดียวกับ ESP32

API:
GET  /api/status
POST /api/pump       JSON: {"on":true}
POST /api/threshold  JSON: {"value":35}

ข้อควรระวัง:
- ต้องปรับค่า SOIL_DRY / SOIL_WET จากการวัดเซนเซอร์จริง
- ตรวจสอบตรรกะ float switch และชนิดรีเลย์ Active LOW/HIGH ก่อนจ่ายไฟ
- ห้ามต่อปั๊ม 12V เข้าขา ESP32 โดยตรง ให้ใช้วงจรรีเลย์/ไดรเวอร์และแหล่งจ่ายที่เหมาะสม
- หากเปิดหน้าเว็บด้วย HTTPS อาจเรียก HTTP ไป ESP32 ไม่ได้ (Mixed Content); ใช้หน้าเว็บแบบ HTTP ในเครือข่ายทดสอบ
- โค้ดนี้เป็นโครงเริ่มต้น ต้องทดสอบอุปกรณ์จริงและเพิ่มระบบความปลอดภัยก่อนใช้งานต่อเนื่อง
